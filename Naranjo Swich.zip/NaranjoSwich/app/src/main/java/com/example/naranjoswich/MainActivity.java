package com.example.naranjoswich;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button userButton, helpButton, shotRecordButton, contentButton, rankingButton;
    // percentageButton;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        sessionManager = new SessionManager(this);

        // Verificar si ya está logueado
        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return; // Evitar que se cargue el MainActivity si no está logueado
        }

        // Inicializar botones
        userButton = findViewById(R.id.userButton);
        helpButton = findViewById(R.id.helpButton);
        shotRecordButton = findViewById(R.id.shotRecordButton);
        contentButton = findViewById(R.id.contentButton);
        rankingButton = findViewById(R.id.rankingButton);
        //statisticsButton = findViewById(R.id.statisticsButton);
        // percentageButton = findViewById(R.id.percentageButton);

        // Asignar listeners para abrir nuevas actividades
        userButton.setOnClickListener(v -> openActivity(UserActivity.class));
        helpButton.setOnClickListener(v -> openActivity(HelpActivity.class));
        shotRecordButton.setOnClickListener(v -> openActivity(ShotRecordActivity.class));
        contentButton.setOnClickListener(v -> openActivity(ContenidoActivity.class));
        rankingButton.setOnClickListener(v -> openActivity(RankingActivity.class));
        //statisticsButton.setOnClickListener(view -> openActivity(EstadisticaActivity.class));

        //rankingButton.setOnClickListener(v -> openActivity(RankingActivity.class));
        // percentageButton.setOnClickListener(v -> openActivity(PercentageActivity.class));
        // contentButton.setOnClickListener(v -> openActivity(ContentActivity.class));
        // statisticsButton.setOnClickListener(v -> openActivity(StatisticsActivity.class));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void openActivity(Class<?> activityClass) {
        Intent intent = new Intent(MainActivity.this, activityClass);
        startActivity(intent);
    }
}
package com.example.naranjoswich;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // Usuario autenticado, redirigir al MainActivity
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
        } else {
            // Usuario no autenticado, redirigir al RegisterActivity
            startActivity(new Intent(SplashActivity.this, RegisterActivity.class));
        }
        finish(); // Finaliza esta actividad
    }
}

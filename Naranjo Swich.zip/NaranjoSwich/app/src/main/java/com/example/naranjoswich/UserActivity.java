package com.example.naranjoswich;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UserActivity extends AppCompatActivity {

    private TextView userNameTextView, userIdTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user);

        TextView reviewsTextView = findViewById(R.id.text_resenas);
        reviewsTextView.setOnClickListener(view -> {showReviewsDialog();});

        Button btnBack = findViewById(R.id.btnBack);
        TextView mensajes = findViewById(R.id.text_mensajes);
        TextView configuracion = findViewById(R.id.text_configuracion);
        userNameTextView = findViewById(R.id.user_name);
        userIdTextView = findViewById(R.id.user_id);

        reviewsTextView.setOnClickListener(view -> showReviewsDialog());

        Intent intent = getIntent();
        String userName = intent.getStringExtra("USERNAME");

        if (userName != null) {
            userNameTextView.setText(userName);
        }

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "");
        String userId = sharedPreferences.getString("userId", "");

        userNameTextView.setText(username);
        userIdTextView.setText("ID: " + userId);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        mensajes.setOnClickListener(v -> startActivity(new Intent(UserActivity.this, MensajesActivity.class)));
        configuracion.setOnClickListener(v -> startActivity(new Intent(UserActivity.this, ConfiguracionActivity.class)));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void showReviewsDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_reviews);
        dialog.setCancelable(true);

        Button closeButton = dialog.findViewById(R.id.closeButton);
        closeButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

}
package com.example.naranjoswich;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String PREF_NAME = "UserSession";
    private static final String IS_LOGGED_IN = "IsLoggedIn";
    private static final String KEY_USERNAME = "Username";

    public SessionManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // Guardar datos de sesión
    public void createSession(String username) {
        editor.putBoolean(IS_LOGGED_IN, true);
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    // Cerrar sesión
    public void logout() {
        editor.clear();
        editor.apply();
    }

    // Verificar si el usuario está logueado
    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGGED_IN, false);
    }

    // Obtener el nombre de usuario de la sesión
    public String getUsername() {
        return sharedPreferences.getString(KEY_USERNAME, null);
    }
}

package com.example.naranjoswich;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MensajesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Message> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_messages);

        recyclerView = findViewById(R.id.recyclerViewMessages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Crear una lista de mensajes de ejemplo
        messageList = new ArrayList<>();
        messageList.add(new Message("", "", ""));
        messageList.add(new Message("", "", ""));
        messageList.add(new Message("", "", ""));

        // Configurar el adaptador
        recyclerView.setAdapter(new MessageAdapter(messageList));

        Button backToUserButton = findViewById(R.id.backToUserButton);
        backToUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MensajesActivity.this, UserActivity.class);
                startActivity(intent);
                finish();
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private static class Message {
        String user;
        String text;
        String time;

        Message(String user, String text, String time) {
            this.user = user;
            this.text = text;
            this.time = time;
        }
    }

    // Adaptador para el RecyclerView
    private class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {
        private final List<MensajesActivity.Message> messages;

        MessageAdapter(List<MensajesActivity.Message> messages) {
            this.messages = messages;
        }

        @NonNull
        @Override
        public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
            return new MessageViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
            MensajesActivity.Message message = messages.get(position);
            holder.userTextView.setText(message.user);
            holder.messageTextView.setText(message.text + " - " + message.time);
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        // ViewHolder para los elementos de la lista
        class MessageViewHolder extends RecyclerView.ViewHolder {
            TextView userTextView;
            TextView messageTextView;

            MessageViewHolder(View itemView) {
                super(itemView);
                userTextView = itemView.findViewById(android.R.id.text1);
                messageTextView = itemView.findViewById(android.R.id.text2);
            }
        }
    }

}
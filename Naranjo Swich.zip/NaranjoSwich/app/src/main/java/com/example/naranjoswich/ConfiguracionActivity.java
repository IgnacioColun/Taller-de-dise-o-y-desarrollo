package com.example.naranjoswich;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ConfiguracionActivity extends AppCompatActivity {

    private EditText newUsernameEditText;
    private Button saveUsernameButton, btnCerrar, backButton;
    private SessionManager sessionManager;

    private DatabaseReference database;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_configuracion);

        btnCerrar = findViewById(R.id.btn_cerrar);
        backButton = findViewById(R.id.backButton);
        saveUsernameButton = findViewById(R.id.saveUsernameButton);
        newUsernameEditText = findViewById(R.id.newUsernameEditText);

        sessionManager = new SessionManager(this);

        // Inicializar Firebase y obtener el userId actual
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        userId = mAuth.getCurrentUser().getUid();
        database = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Botón para cerrar sesión
        btnCerrar.setOnClickListener(v -> {
            sessionManager.logout();
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        // Botón para cambiar el nombre de usuario
        saveUsernameButton.setOnClickListener(v -> {
            String newUsername = newUsernameEditText.getText().toString().trim();

            if (newUsername.isEmpty()) {
                Toast.makeText(this, "Por favor, ingresa un nuevo nombre de usuario", Toast.LENGTH_SHORT).show();
                Log.e("ConfiguracionActivity", "Nuevo nombre de usuario vacío");
            } else {
                // Confirmación del cambio de nombre
                new AlertDialog.Builder(this)
                        .setTitle("Confirmar cambio")
                        .setMessage("¿Estás seguro de que quieres cambiar tu nombre de usuario?")
                        .setPositiveButton("Sí", (dialog, which) -> actualizarNombreUsuario(newUsername))
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });

        // Botón para regresar al UserActivity
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(ConfiguracionActivity.this, UserActivity.class);
            startActivity(intent);
            finish();
        });

        // Ajustar padding para bordes del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void actualizarNombreUsuario(String newUsername) {
        // Actualizar en Firebase Database
        database.child("username").setValue(newUsername).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Log.d("ConfiguracionActivity", "Nombre actualizado en Firebase");

                // Actualizar en SessionManager
                sessionManager.createSession(newUsername);

                Toast.makeText(this, "Nombre de usuario actualizado con éxito", Toast.LENGTH_SHORT).show();

                // Redirigir al UserActivity
                Intent intent = new Intent(ConfiguracionActivity.this, UserActivity.class);
                startActivity(intent);
                finish();
            } else {
                Log.e("ConfiguracionActivity", "Error al actualizar en Firebase");
                Toast.makeText(this, "Error al actualizar el nombre en la base de datos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

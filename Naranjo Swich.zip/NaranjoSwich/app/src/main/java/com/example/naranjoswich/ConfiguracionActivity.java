package com.example.naranjoswich;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ConfiguracionActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_configuracion);

        Button btnCerrar = findViewById(R.id.btn_cerrar);
        Button saveUsernameButton = findViewById(R.id.saveUsernameButton);
        EditText newUsernameEditText = findViewById(R.id.newUsernameEditText);


        btnCerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ConfiguracionActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


        saveUsernameButton.setOnClickListener(v -> {
            String newUsername = newUsernameEditText.getText().toString();

            if (!newUsername.isEmpty()) {
                // Guarda el nuevo nombre en SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("username", newUsername);
                editor.apply();

                // Mensaje de éxito
                Toast.makeText(this, "Nombre de usuario actualizado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Por favor, ingresa un nombre válido", Toast.LENGTH_SHORT).show();
            }
        });

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConfiguracionActivity.this, UserActivity.class);
                startActivity(intent);
                finish();
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void cambiarNombreUsuario(String nuevoNombreUsuario) {
        SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("nombreUsuario", nuevoNombreUsuario);
        editor.apply();
        // Actualiza el TextView o cualquier referencia en ConfigurationActivity
        Toast.makeText(this, "Nombre de usuario actualizado", Toast.LENGTH_SHORT).show();
    }
}